# -*- coding: utf-8 -*-
"""
Auth* related model.

This is where the models used by :mod:`repoze.who` and :mod:`repoze.what` are
defined.

It's perfectly fine to re-use this definition in the Prueba12 application,
though.

"""
import os
from datetime import datetime
import sys
try:
    from hashlib import sha1
except ImportError:
    sys.exit('ImportError: No module named hashlib\n'
             'If you are on python2.4 this library is not part of python. '
             'Please install it. Example: easy_install hashlib')

from sqlalchemy import Table, ForeignKey, Column
from sqlalchemy.types import Unicode, Integer, DateTime , String
from sqlalchemy.orm import relation, synonym

from prueba12.model import DeclarativeBase, metadata, DBSession

__all__ = ['Item']

class Item(DeclarativeBase):
	"""
	Group definition for :mod:`repoze.what`.

	Only the ``group_name`` column is required by :mod:`repoze.what`.

	"""

	__tablename__ = 'Item'

	#{ Columns

	idItem = Column(Integer, autoincrement=True, primary_key=True)

	Nombre = Column(Unicode(16), unique=True, nullable=False)

	Tipo_Item = Column(Unicode(255))

	created = Column(DateTime, default=datetime.now)

def __repr__(self):
	return '<Item: nombre=%s>' % self.Nombre

def __unicode__(self):
	return self.Nombre

	#}

