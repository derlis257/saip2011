# -*- coding: utf-8 -*-

"""WebHelpers used in Prueba12."""

from webhelpers import date, feedgenerator, html, number, misc, text
